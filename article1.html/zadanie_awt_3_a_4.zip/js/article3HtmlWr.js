import OpinionsHandlerMustache from "./opinionsHandlerMustache.js";


window.opnsHndlr = new OpinionsHandlerMustache("review","opinionsContainer","oneOpinion");
window.opnsHndlr.init();